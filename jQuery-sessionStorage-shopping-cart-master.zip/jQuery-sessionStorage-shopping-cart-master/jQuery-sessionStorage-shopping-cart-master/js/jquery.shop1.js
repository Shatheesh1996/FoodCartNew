$(window).on('load', function() {
	var firstItemStock = parseInt(sessionStorage.getItem("firststock"));
	var secondItemStock = parseInt(sessionStorage.getItem("secondstock"));
	var thirdItemStock = parseInt(sessionStorage.getItem("thirdstock"));
	if (!thirdItemStock > 0) {
		$("#third").find('input').hide();
		$("#thirdqty").hide();
		$("#thirdoutofstock").show();
	} else {
		$("#third").find('input').show();
		$("#thirdqty").show();
		$("#thirdoutofstock").hide();
	}
	if (!secondItemStock > 0) {
		$("#second").find('input').hide();
		$("#secondqty").hide();
		$("#secondoutofstock").show();
	} else {
		$("#second").find('input').show();
		$("#secondqty").show();
		$("#secondoutofstock").hide();
	}
	if (!firstItemStock > 0) {
		$("#first").find('input').hide();
		$("#firstqty").hide();
		$("#firstoutofstock").show();
	} else {
		$("#first").find('input').show();
		$("#firstqty").show();
		$("#firstoutofstock").hide();
	}
});

$(document).ready(function() {
	$('#submit-order').click(function() {
		var city = $("input[name=city]").val();
		var address = $("input[name=address]").val();
		var zip = $("input[name=zip]").val();
		var country = $("select[name=country]").val();
		var ary = [];
		$('#checkout-cart tbody tr').each(function(a, b) {
			var name = $('.pname', b).text();
			var qty = parseInt($('.pqty', b).text());
			var price = parseInt($('.pprice', b).text().slice(2));
			ary.push({
				Amount: price,
				Quantity: qty,
				FoodName: name
			});

		});
		alert(country);
		$.ajax({
			type: "POST",
			url: "http://localhost:5000/api/Order/AddOrder",
			contentType: "application/json; charset=utf-8",
			async: false,
			//dataType: "json", 
			data: JSON.stringify({
				pincode: parseInt(zip),
				Address: address,
				City: city,
				Country: country,
				UserId: 1001
			}),
			success: function(data) {
				//alert(JSON.stringify(data));                  
				console.log(data);
				ary.forEach(function(v) {
					v.OrderId = data.orderId;
				})
			}, //End of AJAX Success function  
			error: function(data) {
				alert(data.responseText);
			} //End of AJAX error function  

		});
		$.ajax({
			type: "POST",
			url: "http://localhost:5000/api/OrderDetail/AddOrderDetail",
			contentType: "application/json; charset=utf-8",
			async: false,
			//dataType: "json", 
			data: JSON.stringify(ary),
			success: function(data) {
				//alert(JSON.stringify(data));                  
				console.log(data);
				alert("Order Successful : " + ary[0].OrderId)
				sessionStorage.removeItem("winery-cart")
				//window.location.href='index.html'
				location.replace("https://www.w3schools.com");
			}, //End of AJAX Success function  
			error: function(data) {
				alert(data.responseText);
			} //End of AJAX error function  

		});
	});
});